<template>
    <div class="main">
        <div class="container">
            <div class="search">
                <el-row :gutter="20" style="margin-top: 20px;">
                    <el-col :span="2" :offset="1">
                        <el-button size="small" style="width: 100px" type="primary" icon="el-icon-circle-plus-outline"
                                   @click="doOrder">Order</el-button>
                    </el-col>
                    <el-col :span="3" :offset="0">
                        <el-select v-model="selectedEvent" placeholder="event select" clearable>
                            <el-option v-for="(item,index) in eventList" :key="index" :label="item.eventName" :value="item"></el-option>
                        </el-select>
                    </el-col>
                    <el-col :span="3" :offset="10">
                        <el-input clearable size="mini" placeholder="productName" suffix-icon="el-icon-search"
                                  v-model="searchCondition.productName" @change="getTableData"></el-input>
                    </el-col>
                    <el-col :span="3" :offset="0">
                        <el-input clearable size="mini" placeholder="category" suffix-icon="el-icon-search"
                                  v-model="searchCondition.category" @change="getTableData"></el-input>
                    </el-col>

                </el-row>
            </div>
            <div class="table">
                <el-table :data="tableList" style="width: 95%" height="100%" max-height="100%" empty-text="No Data"
                          :cell-style="{ padding: '5px' }" @selection-change="handleSelectionChange" ref="multipleTable">
                    <el-table-column
                        type="selection"
                        width="55">
                    </el-table-column>
                    <el-table-column label="productId" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.productId }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="pic" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span><el-image style="width: 100px; height: 100px"  :src="'http://127.0.0.1:8080/products/local2Url?name=' + scope.row.picUrl" :preview-src-list="['http://127.0.0.1:8080/products/local2Url?name=' + scope.row.picUrl]"></el-image></span>
                        </template>
                    </el-table-column>
                    <el-table-column label="productName" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.productName }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="productStatus" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.productStatus }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="quantity" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.quantity }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="price" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.price }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="num" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <el-button type="primary" size="mini" icon="el-icon-minus" @click="decrement(scope.row)" circle></el-button>
                            <el-tag size="mini" style="margin-left: 5px;margin-right: 5px">{{ scope.row.num }}</el-tag>
                            <el-button type="primary" size="mini" icon="el-icon-plus" @click="increment(scope.row)" circle></el-button>
                        </template>
                    </el-table-column>
                    <el-table-column label="category" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.category }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="color" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.color }}</span>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
            <div class="bottom">
                <div class="pagination">
                    <el-pagination :page-size="size" :pager-count="11" layout="total, prev, pager, next" :total="total" :current-page="searchCondition.pageIndex" @current-change="pageNumberOnChange">
                    </el-pagination>
                </div>
            </div>
        </div>
    </div>
</template>
<script>


export default {
    data() {
        return {
            searchCondition: {
                productName: null,
                category: null,
                startingPrice: null,
                endingPrice: null
            },
            tableList: [],
            detailObj: {},
            editObj: {},
            createObj: {},
            isDetailDialogShow: false,
            isCreateDialogShow: false,
            isEditDialogShow: false,
            total: 0,
            size: 0,
            eventList: [],
            selectedEvent: null,
            multipleSelection: []
        };
    },
    methods: {
        decrement(row) {
            if (row.num === 0) return;
            row.num--;
            this.$forceUpdate();
        },
        increment(row) {
            row.num++;
            this.$forceUpdate();
        },
        toggleSelection(rows) {
            if (rows) {
                rows.forEach(row => {
                    this.$refs.multipleTable.toggleRowSelection(row);
                });
            } else {
                this.$refs.multipleTable.clearSelection();
            }
        },
        handleSelectionChange(val) {
            this.multipleSelection = val;
        },
        formatDateTime(dateTimeString, format = "yyyy-mm-dd HH:MM:SS") {
            const originalDate = new Date(dateTimeString);

            const year = originalDate.getFullYear();
            const month = ("0" + (originalDate.getMonth() + 1)).slice(-2);
            const day = ("0" + originalDate.getDate()).slice(-2);

            const hours = ("0" + originalDate.getHours()).slice(-2);
            const minutes = ("0" + originalDate.getMinutes()).slice(-2);
            const seconds = ("0" + originalDate.getSeconds()).slice(-2);

            const formattedDateTime = format
                .replace("yyyy", year)
                .replace("mm", month)
                .replace("dd", day)
                .replace("HH", hours)
                .replace("MM", minutes)
                .replace("SS", seconds);

            return formattedDateTime;
        },
        getTableData() {
            this.$http.getProductList(this.searchCondition).then(res => {
                this.tableList = res.data.records;
                this.total = res.data.total;
                this.size = res.data.size;
                for (let item of this.tableList) {
                    item.num = 0;
                }
            })
        },
        handleDelete(row){
            let message = "<span style='color: orange;font-size:15px'> [Delete] </span> this data permanently，continue？"
            this.$hint.confirm(message).then(res => {
                if (res) {
                    let arr = [row.productId];
                    this.$http.deleteProduct(arr).then(res => {
                        if (res.code === 1) {
                            this.getTableData();
                        }
                    })
                }
            })
        },
        pageNumberOnChange() {
            this.getTableData();
        },

        handleEdit() {
            this.$http.updateProduct(this.editObj).then(res => {
                if (res.code === 1) {
                    this.isEditDialogShow = false;
                    this.getTableData();
                }
            })
        },

        handleCreate() {
            this.$http.createProduct(this.createObj).then(res => {
                if (res.code === 1) {
                    this.isCreateDialogShow = false;
                    this.getTableData();
                }
            })
        },

        beforeUpload(file) {
            const isLt10M = file.size / 1024 / 1024 < 10;
            if (!isLt10M) {
                this.$message.error("Limit 10MB!");
            }
            return isLt10M;
        },

        onUpload(e) {
            let that = this;
            let file = e.file;
            that.$http.uploadFile(file).then(res => {
                if (res.code === 1) {
                    that.createObj.picUrl = res.data;
                    that.editObj.picUrl = res.data;
                    this.$forceUpdate();
                }
            });
        },
        doOrder() {
            if (this.selectedEvent === null || this.selectedEvent === '') {
                this.$hint.message.error('select event first.');
                return;
            }
            let orderDetails = [];

            for (let item of this.multipleSelection) {
                orderDetails.push({
                    productId: item.productId,
                    productQuantity: item.num,
                })
            }

            let orderDto = {
                eventId: this.selectedEvent.eventId,
                userId: this.$store.state.currentUser.userId,
                address: this.$store.state.currentUser.address,
                event: this.selectedEvent,
                orderDetails: orderDetails
            }

            this.$http.book(orderDto).then(res => {
                if(res.code === 1) {
                    this.$hint.notify.success('order success.');
                    this.getTableData();
                }
            })
        }

    },
    created() {
        this.getTableData();

        this.$http.getByTeam({teamId: this.$store.state.currentUser.teamId}).then(res => {
            this.eventList = res.data.records;
        })



    }
};
</script>
<style scoped>
/deep/ .el-select-dropdown__item span {
    font-size: 12px;
}

/deep/ .el-form-item__label {
    font-size: 12px;
    letter-spacing: 1px;
}

/deep/ .el-input__inner {
    height: 34px;
}

/deep/ .el-form-item {
    margin-bottom: 25px;
}

/deep/ .el-input__inner {
    font-size: 12px;
}

/deep/ .el-button {
    background-color: #FCA49B !important;
    border: none !important;
}

.main {
    height: 100%;
}

.search {
    flex: 2;
}

.container {
    height: 100%;
    /* border: 1px solid red; */
    display: flex;
    width: 100%;
    flex-direction: column;
}

::v-deep ::-webkit-scrollbar {
    width: 0;
    height: 0;
}

.table {
    flex: 15;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    width: 98%;
    margin: auto;
}

/deep/ .el-table {
    background-color: rgba(243, 245, 237, 0) !important;
    font-size: 12px;
    font-weight: 400;
    letter-spacing: 1px;
    margin: auto;
}

/deep/ .el-table tr {
    background-color: rgba(243, 245, 237, 0) !important;
}

/deep/ .el-table th {
    background-color: rgba(243, 245, 237, 0) !important;
}

/deep/ .el-tooltip__popper {
    border: 1px solid red;
}

.bottom {
    flex: 0.5;
    display: flex;
    flex-direction: column;
    align-items: center;
}

/deep/ .el-pagination {
    background-color: rgba(243, 245, 237, 0) !important;
    margin: auto;
}

/deep/ .el-pagination ul {
    background-color: rgba(243, 245, 237, 0) !important;
}

/deep/ .el-pagination li {
    background-color: rgba(243, 245, 237, 0) !important;
}

/deep/ .el-pagination button {
    background-color: rgba(243, 245, 237, 0) !important;
}

.avatar-uploader-icon {
    border: 1px dashed rgb(170, 163, 163);
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}

.avatar-uploader-icon:hover {
    border-color: #409eff;
}

.avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 100px;
    height: 100px;
    line-height: 100px;
    text-align: center;
}

.avatar {
    width: 100px;
    height: 100px;
    display: block;
    border-radius: 5px;
}
</style>