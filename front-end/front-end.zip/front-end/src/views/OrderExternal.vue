<template>
    <div class="main">
        <el-dialog :visible.sync="isCreateDialogShow" width="45%" center>
            <div slot="title" class="dialog-title">
                Add
            </div>
            <el-form :model="createObj" status-icon label-width="150px" class="demo-ruleForm" style="font-size: 10px">
                <el-form-item label="eventId :">
                    <el-input clearable v-model="createObj.eventId" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="userId :">
                    <el-input clearable v-model="createObj.userId" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="address :">
                    <el-input clearable v-model="createObj.address" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="trackingNumber :">
                    <el-input clearable v-model="createObj.trackingNumber" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="orderStatus :">
                    <el-select v-model="createObj.orderStatus" style="width: 85%" placeholder="orderStatus" suffix-icon="el-icon-search" clearable>
                        <el-option label="Stocking up" value="Stocking up"></el-option>
                        <el-option label="Transit" value="Transit"></el-option>
                        <el-option label="Arrived" value="Arrived"></el-option>
                        <el-option label="Returned" value="Returned"></el-option>
                    </el-select>
                </el-form-item>

            </el-form>
            <div style="display: flex;align-items: center;">
                <el-button  style="margin: auto; margin-top: 2vh; width: 50%" type="primary" @click="handleCreate">Submit</el-button>
            </div>
        </el-dialog>

        <el-dialog :visible.sync="isEditDialogShow" width="45%" center>
            <div slot="title" class="dialog-title">
                Edit
            </div>
            <el-form :model="editObj" status-icon label-width="150px" class="demo-ruleForm" style="font-size: 10px">
                <el-form-item label="eventId :">
                    <el-input clearable v-model="editObj.eventId" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="userId :">
                    <el-input clearable v-model="editObj.userId" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="address :">
                    <el-input clearable v-model="editObj.address" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="trackingNumber :">
                    <el-input clearable v-model="editObj.trackingNumber" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="orderStatus :">
                    <el-select v-model="editObj.orderStatus" style="width: 85%" placeholder="orderStatus" suffix-icon="el-icon-search" clearable>
                        <el-option label="Stocking up" value="Stocking up"></el-option>
                        <el-option label="Transit" value="Transit"></el-option>
                        <el-option label="Arrived" value="Arrived"></el-option>
                        <el-option label="Returned" value="Returned"></el-option>
                    </el-select>
                </el-form-item>
            </el-form>
            <div style="display: flex;align-items: center;">
                <el-button  style="margin: auto; margin-top: 2vh; width: 50%" type="primary" @click="handleEdit">Submit</el-button>
            </div>
        </el-dialog>

        <div class="container">
            <div class="search">
                <el-row :gutter="20" style="margin-top: 20px;">
                    <el-col :span="3" :offset="19">
                        <el-select v-model="searchCondition.orderStatus" placeholder="orderStatus" @change="getTableData" suffix-icon="el-icon-search" clearable>
                            <el-option label="Stocking up" value="Stocking up"></el-option>
                            <el-option label="Transit" value="Transit"></el-option>
                            <el-option label="Arrived" value="Arrived"></el-option>
                            <el-option label="Returned" value="Returned"></el-option>
                        </el-select>
                    </el-col>
                </el-row>
            </div>
            <div class="table">
                <el-table :data="tableList" style="width: 95%" height="100%" max-height="100%" empty-text="No Data"
                          :cell-style="{ padding: '5px' }">
                    <el-table-column label="orderId" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.orderId }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="eventId" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.eventId }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="userId" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.userId }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="trackingNumber" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.trackingNumber }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="address" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.address }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="orderStatus" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.orderStatus }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="bookTime" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ formatDateTime(scope.row.bookTime) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="returnTime" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ formatDateTime(scope.row.returnTime) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="Operation" min-width="20">
                        <template slot-scope="scope">
                            <el-button size="normal" type="success" :disabled="scope.row.orderStatus !== 'In Transit'" @click="arrived(scope.row)">Arrived</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
            <div class="bottom">
                <div class="pagination">
                    <el-pagination :page-size="size" :pager-count="11" layout="total, prev, pager, next" :total="total" :current-page="searchCondition.pageIndex" @current-change="pageNumberOnChange">
                    </el-pagination>
                </div>
            </div>
        </div>
    </div>
</template>
<script>


export default {
    data() {
        return {
            searchCondition: {
                orderStatus: null,
            },
            tableList: [],
            detailObj: {},
            editObj: {},
            createObj: {},
            isDetailDialogShow: false,
            isCreateDialogShow: false,
            isEditDialogShow: false,
            total: 0,
            size: 0
        };
    },
    methods: {
        arrived(row) {
            this.$http.updateStatusToArrived({orderId: row.orderId}).then(res => {
                if (res.code === 1) {
                    this.getTableData();
                    this.$hint.notify.success('Arrived success');
                }
            })
        },
        formatDateTime(dateTimeString, format = "yyyy-mm-dd HH:MM:SS") {
            const originalDate = new Date(dateTimeString);

            const year = originalDate.getFullYear();
            const month = ("0" + (originalDate.getMonth() + 1)).slice(-2);
            const day = ("0" + originalDate.getDate()).slice(-2);

            const hours = ("0" + originalDate.getHours()).slice(-2);
            const minutes = ("0" + originalDate.getMinutes()).slice(-2);
            const seconds = ("0" + originalDate.getSeconds()).slice(-2);

            const formattedDateTime = format
                .replace("yyyy", year)
                .replace("mm", month)
                .replace("dd", day)
                .replace("HH", hours)
                .replace("MM", minutes)
                .replace("SS", seconds);

            return formattedDateTime;
        },
        getTableData() {
            this.$http.getOrderList(this.searchCondition).then(res => {
                this.tableList = res.data.records;
                this.total = res.data.total;
                this.size = res.data.size;
            })
        },
        handleDelete(row){
            let message = "<span style='color: orange;font-size:15px'> [Delete] </span> this data permanently，continue？"
            this.$hint.confirm(message).then(res => {
                if (res) {
                    let arr = [row.orderId];
                    this.$http.deleteOrder(arr).then(res => {
                        if (res.code === 1) {
                            this.getTableData();
                        }
                    })
                }
            })
        },
        pageNumberOnChange() {
            this.getTableData();
        },

        handleEdit() {
            this.$http.updateOrder(this.editObj).then(res => {
                if (res.code === 1) {
                    this.isEditDialogShow = false;
                    this.getTableData();
                }
            })
        },

        handleCreate() {
            this.$http.createOrder(this.createObj).then(res => {
                if (res.code === 1) {
                    this.isCreateDialogShow = false;
                    this.getTableData();
                }
            })
        },



    },
    created() {
        this.getTableData();
    }
};
</script>
<style scoped>
/deep/ .el-select-dropdown__item span {
    font-size: 12px;
}

/deep/ .el-form-item__label {
    font-size: 12px;
    letter-spacing: 1px;
}

/deep/ .el-button {
    background-color: #FCA49B !important;
    border: none !important;
}

/deep/ .el-input__inner {
    height: 34px;
}

/deep/ .el-form-item {
    margin-bottom: 25px;
}

/deep/ .el-input__inner {
    font-size: 12px;
}

.main {
    height: 100%;
}

.search {
    flex: 2;
}

.container {
    height: 100%;
    /* border: 1px solid red; */
    display: flex;
    width: 100%;
    flex-direction: column;
}

::v-deep ::-webkit-scrollbar {
    width: 0;
    height: 0;
}

.table {
    flex: 15;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    width: 98%;
    margin: auto;
}

/deep/ .el-table {
    background-color: rgba(243, 245, 237, 0) !important;
    font-size: 12px;
    font-weight: 400;
    letter-spacing: 1px;
    margin: auto;
}

/deep/ .el-table tr {
    background-color: rgba(243, 245, 237, 0) !important;
}

/deep/ .el-table th {
    background-color: rgba(243, 245, 237, 0) !important;
}

/deep/ .el-tooltip__popper {
    border: 1px solid red;
}

.bottom {
    flex: 0.5;
    display: flex;
    flex-direction: column;
    align-items: center;
}

/deep/ .el-pagination {
    background-color: rgba(243, 245, 237, 0) !important;
    margin: auto;
}

/deep/ .el-pagination ul {
    background-color: rgba(243, 245, 237, 0) !important;
}

/deep/ .el-pagination li {
    background-color: rgba(243, 245, 237, 0) !important;
}

/deep/ .el-pagination button {
    background-color: rgba(243, 245, 237, 0) !important;
}

.avatar-uploader-icon {
    border: 1px dashed rgb(170, 163, 163);
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}

.avatar-uploader-icon:hover {
    border-color: #409eff;
}

.avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 100px;
    height: 100px;
    line-height: 100px;
    text-align: center;
}

.avatar {
    width: 100px;
    height: 100px;
    display: block;
    border-radius: 5px;
}
</style>