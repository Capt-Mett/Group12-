<template>
    <div class="main">

        <el-dialog :visible.sync="isCreateDialogShow" width="45%" center>
            <div slot="title" class="dialog-title">
                Add
            </div>
            <el-form :model="createObj" status-icon label-width="150px" class="demo-ruleForm" style="font-size: 10px">
                <el-form-item label="pic :">
                    <el-upload class="avatar-uploader" action="" accept="image/*" :show-file-list="false" :before-upload="beforeUpload" :http-request="onUpload">
                        <img v-if="createObj.picUrl !== null && createObj.picUrl !== '' && createObj.picUrl !== undefined" :src="'http://127.0.0.1:8080/products/local2Url?name=' + createObj.picUrl"
                             class="avatar"/>
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                </el-form-item>
                <el-form-item label="productName :">
                    <el-input clearable v-model="createObj.productName" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="category :">
                    <el-input clearable v-model="createObj.category" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="quantity :">
                    <el-input clearable v-model="createObj.quantity" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="color :">
                    <el-input clearable v-model="createObj.color" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="price :">
                    <el-input clearable v-model="createObj.price" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="productStatus :">
                    <el-input clearable v-model="createObj.productStatus" style="width: 85%"></el-input>
                </el-form-item>
            </el-form>
            <div style="display: flex;align-items: center;">
                <el-button  style="margin: auto; margin-top: 2vh; width: 50%" type="primary" @click="handleCreate">Submit</el-button>
            </div>
        </el-dialog>

        <el-dialog :visible.sync="isEditDialogShow" width="45%" center>
            <div slot="title" class="dialog-title">
                Edit
            </div>
            <el-form :model="editObj" status-icon label-width="150px" class="demo-ruleForm" style="font-size: 10px">
                <el-form-item label="pic :">
                    <el-upload class="avatar-uploader" action="" accept="image/*" :show-file-list="false" :before-upload="beforeUpload" :http-request="onUpload">
                        <img v-if="editObj.picUrl !== null && editObj.picUrl !== '' && editObj.picUrl !== undefined" :src="'http://127.0.0.1:8080/products/local2Url?name=' + editObj.picUrl"
                             class="avatar"/>
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                </el-form-item>
                <el-form-item label="productName :">
                    <el-input clearable v-model="editObj.productName" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="category :">
                    <el-input clearable v-model="editObj.category" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="quantity :">
                    <el-input clearable v-model="editObj.quantity" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="color :">
                    <el-input clearable v-model="editObj.color" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="price :">
                    <el-input clearable v-model="editObj.price" style="width: 85%"></el-input>
                </el-form-item>
                <el-form-item label="productStatus :">
                    <el-input clearable v-model="editObj.productStatus" style="width: 85%"></el-input>
                </el-form-item>
            </el-form>
            <div style="display: flex;align-items: center;">
                <el-button  style="margin: auto; margin-top: 2vh; width: 50%" type="primary" @click="handleEdit">Submit</el-button>
            </div>
        </el-dialog>

        <div class="container">
            <div class="search">
                <el-row :gutter="20" style="margin-top: 20px;">
                    <el-col :span="2" :offset="1">
                        <el-button size="normal" style="width: 100px" type="primary" icon="el-icon-circle-plus-outline"
                                   @click="() => { this.isCreateDialogShow = true; }">Create</el-button>
                    </el-col>

                    <el-col :span="3" :offset="14">
                        <el-input clearable size="mini" placeholder="productName" suffix-icon="el-icon-search"
                                  v-model="searchCondition.productName" @change="getTableData"></el-input>
                    </el-col>
                    <el-col :span="3" :offset="0">
                        <el-input clearable size="mini" placeholder="category" suffix-icon="el-icon-search"
                                  v-model="searchCondition.category" @change="getTableData"></el-input>
                    </el-col>

                </el-row>
            </div>
            <div class="table">
                <el-table :data="tableList" style="width: 95%" height="100%" max-height="100%" empty-text="No Data"
                          :cell-style="{ padding: '5px' }">
                    <el-table-column label="productId" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.productId }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="pic" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span><el-image style="width: 100px; height: 100px"  :src="'http://127.0.0.1:8080/products/local2Url?name=' + scope.row.picUrl" :preview-src-list="['http://127.0.0.1:8080/products/local2Url?name=' + scope.row.picUrl]"></el-image></span>
                        </template>
                    </el-table-column>
                    <el-table-column label="productName" min-width="20" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.productName }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="productStatus" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.productStatus }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="quantity" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.quantity }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="price" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.price }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="category" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.category }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="color" min-width="10" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <span>{{ scope.row.color }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="Operation" min-width="15">
                        <template slot-scope="scope">

                            <el-button size="normal" type="primary" @click="() => {editObj = $util.copyShallow(scope.row);isEditDialogShow = true;}" icon="el-icon-edit">Edit</el-button>

                            <el-button size="normal" type="danger" @click="handleDelete(scope.row)" icon="el-icon-delete">Delete</el-button>

                        </template>
                    </el-table-column>
                </el-table>
            </div>
            <div class="bottom">
                <div class="pagination">
                    <el-pagination :page-size="size" :pager-count="11" layout="total, prev, pager, next" :total="total" :current-page="searchCondition.pageIndex" @current-change="pageNumberOnChange">
                    </el-pagination>
                </div>
            </div>
        </div>
    </div>
</template>
<script>


export default {
    data() {
        return {
            searchCondition: {
                productName: null,
                category: null,
                startingPrice: null,
                endingPrice: null
            },
            tableList: [],
            detailObj: {},
            editObj: {},
            createObj: {},
            isDetailDialogShow: false,
            isCreateDialogShow: false,
            isEditDialogShow: false,
            total: 0,
            size: 0
        };
    },
    methods: {
        formatDateTime(dateTimeString, format = "yyyy-mm-dd HH:MM:SS") {
            const originalDate = new Date(dateTimeString);

            const year = originalDate.getFullYear();
            const month = ("0" + (originalDate.getMonth() + 1)).slice(-2);
            const day = ("0" + originalDate.getDate()).slice(-2);

            const hours = ("0" + originalDate.getHours()).slice(-2);
            const minutes = ("0" + originalDate.getMinutes()).slice(-2);
            const seconds = ("0" + originalDate.getSeconds()).slice(-2);

            const formattedDateTime = format
                .replace("yyyy", year)
                .replace("mm", month)
                .replace("dd", day)
                .replace("HH", hours)
                .replace("MM", minutes)
                .replace("SS", seconds);

            return formattedDateTime;
        },
        getTableData() {
            this.$http.getProductList(this.searchCondition).then(res => {
                this.tableList = res.data.records;
                this.total = res.data.total;
                this.size = res.data.size;
            })
        },
        handleDelete(row){
            let message = "<span style='color: orange;font-size:15px'> [Delete] </span> this data permanently，continue？"
            this.$hint.confirm(message).then(res => {
                if (res) {
                    let arr = [row.productId];
                    this.$http.deleteProduct(arr).then(res => {
                        if (res.code === 1) {
                            this.getTableData();
                        }
                    })
                }
            })
        },
        pageNumberOnChange() {
            this.getTableData();
        },

        handleEdit() {
            this.$http.updateProduct(this.editObj).then(res => {
                if (res.code === 1) {
                    this.isEditDialogShow = false;
                    this.getTableData();
                }
            })
        },

        handleCreate() {
            this.$http.createProduct(this.createObj).then(res => {
                if (res.code === 1) {
                    this.isCreateDialogShow = false;
                    this.getTableData();
                }
            })
        },

        beforeUpload(file) {
            const isLt10M = file.size / 1024 / 1024 < 10;
            if (!isLt10M) {
                this.$message.error("Limit 10MB!");
            }
            return isLt10M;
        },

        onUpload(e) {
            let that = this;
            let file = e.file;
            that.$http.uploadFile(file).then(res => {
                if (res.code === 1) {
                    that.createObj.picUrl = res.data;
                    that.editObj.picUrl = res.data;
                    this.$forceUpdate();
                }
            });
        },

    },
    created() {
        this.getTableData();
    }
};
</script>
<style scoped>
/deep/ .el-select-dropdown__item span {
    font-size: 12px;
}

/deep/ .el-form-item__label {
    font-size: 12px;
    letter-spacing: 1px;
}

/deep/ .el-input__inner {
    height: 34px;
}

/deep/ .el-form-item {
    margin-bottom: 25px;
}

/deep/ .el-button {
    background-color: #FCA49B !important;
    border: none !important;
}

/deep/ .el-input__inner {
    font-size: 12px;
}

.main {
    height: 100%;
}

.search {
    flex: 2;
}

.container {
    height: 100%;
    /* border: 1px solid red; */
    display: flex;
    width: 100%;
    flex-direction: column;
}

::v-deep ::-webkit-scrollbar {
    width: 0;
    height: 0;
}

.table {
    flex: 15;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    width: 98%;
    margin: auto;
}

/deep/ .el-table {
    background-color: rgba(243, 245, 237, 0) !important;
    font-size: 12px;
    font-weight: 400;
    letter-spacing: 1px;
    margin: auto;
}

/deep/ .el-table tr {
    background-color: rgba(243, 245, 237, 0) !important;
}

/deep/ .el-table th {
    background-color: rgba(243, 245, 237, 0) !important;
}

/deep/ .el-tooltip__popper {
    border: 1px solid red;
}

.bottom {
    flex: 0.5;
    display: flex;
    flex-direction: column;
    align-items: center;
}

/deep/ .el-pagination {
    background-color: rgba(243, 245, 237, 0) !important;
    margin: auto;
}

/deep/ .el-pagination ul {
    background-color: rgba(243, 245, 237, 0) !important;
}

/deep/ .el-pagination li {
    background-color: rgba(243, 245, 237, 0) !important;
}

/deep/ .el-pagination button {
    background-color: rgba(243, 245, 237, 0) !important;
}

.avatar-uploader-icon {
    border: 1px dashed rgb(170, 163, 163);
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}

.avatar-uploader-icon:hover {
    border-color: #409eff;
}

.avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 100px;
    height: 100px;
    line-height: 100px;
    text-align: center;
}

.avatar {
    width: 100px;
    height: 100px;
    display: block;
    border-radius: 5px;
}
</style>