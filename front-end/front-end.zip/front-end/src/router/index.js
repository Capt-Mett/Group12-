import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
    {
        path: '/',
        name: 'Login',
        component: () => import('../views/Login.vue'),
    },
    {
        path: '/ManagerIndex',
        name: 'ManagerIndex',
        component: () => import('../views/ManagerIndex.vue'),
        children: [
            {
                path: '',
                name: 'UserManagement',
                component: () => import('../views/UserManagement.vue'),
            },
            {
                path: 'TeamManagement',
                name: 'TeamManagement',
                component: () => import('../views/TeamManagement.vue'),
            },
            {
                path: 'EventManagement',
                name: 'EventManagement',
                component: () => import('../views/EventManagement.vue'),
            },
            {
                path: 'ProductManagement',
                name: 'ProductManagement',
                component: () => import('../views/ProductManagement.vue'),
            },
            {
                path: 'OrderManagement',
                name: 'OrderManagement',
                component: () => import('../views/OrderManagement.vue'),
            }
        ]
    },
    {
        path: '/InternalUserIndex',
        name: 'InternalUserIndex',
        component: () => import('../views/InternalUserIndex.vue'),
        children: [
            {
                path: '',
                name: 'ProductInternalManagement',
                component: () => import('../views/ProductInternalManagement.vue'),
            },
            {
                path: 'EventInternalManagement',
                name: 'EventInternalManagement',
                component: () => import('../views/EventInternalManagement.vue'),
            },
            {
                path: 'OrderInternalManagement',
                name: 'OrderInternalManagement',
                component: () => import('../views/OrderInternalManagement.vue'),
            },
            {
                path: 'TeamInternalManagement',
                name: 'TeamInternalManagement',
                component: () => import('../views/TeamInternalManagement.vue'),
            },
        ]
    },
    {
        path: '/ExternalUserIndex',
        name: 'ExternalUserIndex',
        component: () => import('../views/ExternalUserIndex.vue'),
        children: [
            {
                path: '',
                name: 'EventExternal',
                component: () => import('../views/EventExternal.vue'),
            },
            {
                path: 'OrderExternal',
                name: 'OrderExternal',
                component: () => import('../views/OrderExternal.vue'),
            },
            {
                path: 'ExternalProduct',
                name: 'ExternalProduct',
                component: () => import('../views/ExternalProduct.vue'),
            },
        ]
    }
]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

export default router
