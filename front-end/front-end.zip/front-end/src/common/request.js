import axios from 'axios'
import store from '../store/index'
import NProgress from 'nprogress';
import 'nprogress/nprogress.css';
import {Loading} from 'element-ui'
import router from '../router/index.js'
// import qs from 'qs';

export function request(config, autoRemote = null) {
    let axiosCreateConfig = {
        // baseURL: autoRemote === null ? 'http://47.94.36.16:18002' : autoRemote,
        // baseURL: autoRemote === null ? 'http://localhost:18082' : autoRemote,
        baseURL: autoRemote === null ? 'http://127.0.0.1:8080' : autoRemote,
        timeout: 8000
    };

    //
    NProgress.start();
    let loading = Loading.service({
        text: '...',
    });

    const instance = axios.create(axiosCreateConfig);

    // let that = this



    //
    instance.interceptors.request.use(config => {
        //2.（（token）），
        //config，。

        if (store.state.token != null) {
            config.headers.token = 'Bearer ' + store.state.token;
        }
        return config;
    }, err => {
        console.log(err);
        //
        NProgress.done();
        loading.close();
    });

    //
    instance.interceptors.response.use(res => {
        NProgress.done();
        loading.close();

        let type = res.data.type;
        let message = res.data.message;
        let statusCode = res.data.statusCode;

        let notifyConfig = {};
        notifyConfig.message = '<i style="color: orange">[' + statusCode + ']  </i>  ' + message;
        notifyConfig.position = 'top-right';
        notifyConfig.showClose = true;
        notifyConfig.dangerouslyUseHTMLString = true;
        switch (type) {
            case 1:
                notifyConfig.title = '';
                notifyConfig.type = 'info';
                notifyConfig.duration = 3000;
                break;
            case 2:
                notifyConfig.title = '';
                notifyConfig.type = 'success';
                notifyConfig.duration = 3000;
                break;
            case 3:
                notifyConfig.title = '';
                notifyConfig.type = 'warning';
                notifyConfig.duration = 4500;
                break;
            case 4:
                notifyConfig.title = '';
                notifyConfig.type = 'error';
                notifyConfig.duration = 4500;
                break;
            case 5:
                notifyConfig.title = '';
                notifyConfig.type = 'warning';
                notifyConfig.duration = 0;
                store.commit("setToken", null);
                store.commit("setCurrentUser", null);
                router.replace('/');
                break;
            default:
                break;
        }


        return res.data;
    }, err => {
        console.log(err);
        switch (err.message) {
            case 'Network Error':    //    
                break;
            case 'timeout of 8000ms exceeded':   //
                break;
        }


        NProgress.done();
        loading.close();
    });



    return instance(config)
}