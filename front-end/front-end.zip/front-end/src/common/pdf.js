import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'


class PdfLoader {
  constructor(ele, pdfFileName, splitClassName) {
    this.ele = ele
    this.pdfFileName = pdfFileName
    this.splitClassName = splitClassName
    this.A4_WIDTH = 595
    this.A4_HEIGHT = 842
  }

  async getPDF(resolve) {
    const ele = this.ele
    const pdfFileName = this.pdfFileName
    const eleW = ele.offsetWidth// 
    const eleH = ele.scrollHeight// 
    const eleOffsetTop = ele.offsetTop// 
    const eleOffsetLeft = ele.offsetLeft// 
    const canvas = document.createElement('canvas')
    let abs = 0
    const win_in = document.documentElement.clientWidth || document.body.clientWidth// （）
    const win_out = window.innerWidth// （）
    if (win_out > win_in) {
      abs = (win_out - win_in) / 2// 
    }
    canvas.width = eleW * 2// &&
    canvas.height = eleH * 2
    const context = canvas.getContext('2d')
    context.scale(2, 2) // 
    context.translate(-eleOffsetLeft - abs, -eleOffsetTop)
    html2canvas(ele, {
      useCORS: true// canvas, 。
    }).then(async canvas => {
      const contentWidth = canvas.width
      const contentHeight = canvas.height
      // pdfhtmlcanvas;
      const pageHeight = (contentWidth / this.A4_WIDTH) * this.A4_HEIGHT //  pageHeight/canvas.width = a4/a4// canvas.width
      // pdfhtml
      let leftHeight = contentHeight
      // 
      let position = 0
      // a4[595,842],，htmlcanvaspdf
      const imgWidth = this.A4_WIDTH - 10 // -10
      const imgHeight = (this.A4_WIDTH / contentWidth) * contentHeight
      const pageData = canvas.toDataURL('image/jpeg', 1.0)
      const pdf = jsPDF('', 'pt', 'a4')
      // ，html，pdf(841.89)
      // pdf，
      if (leftHeight < pageHeight) {
        // pdf.addImage(pageData, 'JPEG', ，，，)pdf；
        pdf.addImage(pageData, 'JPEG', 5, 0, imgWidth, imgHeight)
        // pdf.addImage(pageData, 'JPEG', 20, 40, imgWidth, imgHeight);
      } else {
        // 
        while (leftHeight > 0) {
          pdf.addImage(pageData, 'JPEG', 5, position, imgWidth, imgHeight)
          leftHeight -= pageHeight
          position -= this.A4_HEIGHT
          // 
          if (leftHeight > 0) {
            pdf.addPage()
          }
        }
      }
      pdf.save(pdfFileName + '.pdf', { returnPromise: true }).then(() => {
        // div 
        const doms = document.querySelectorAll('.emptyDiv')
        for (let i = 0; i < doms.length; i++) {
          doms[i].remove()
        }
      })
      this.ele.style.height = ''
      resolve()
    })
  }
	//（）A4
  async outPutPdfFn(pdfFileName) {
    return new Promise((resolve, reject) => {
      this.ele.style.height = 'initial'
      pdfFileName ? this.pdfFileName = pdfFileName : null
      const target = this.ele
      const pageHeight = target.scrollWidth / this.A4_WIDTH * this.A4_HEIGHT
      // dom，classitemdom
      const domList = document.getElementsByClassName(this.splitClassName)
      // ，doma4，domdom，，
      let pageNum = 1 // pdf
      const eleBounding = this.ele.getBoundingClientRect()
      for (let i = 0; i < domList.length; i++) {
        const node = domList[i]
        const bound = node.getBoundingClientRect()
        const offset2Ele = bound.top - eleBounding.top
        const currentPage = Math.ceil((bound.bottom - eleBounding.top) / pageHeight) // 
        if (pageNum < currentPage) {
          pageNum++
          const divParent = domList[i].parentNode // div
          const newNode = document.createElement('div')
          newNode.className = 'emptyDiv'
          newNode.style.background = 'white'
          newNode.style.height = (pageHeight * (pageNum - 1) - offset2Ele + 30) + 'px' // +30
          newNode.style.width = '100%'
          divParent.insertBefore(newNode, node) //，
        }
      }
      // ，
      this.getPDF(resolve, reject)
    })
  }
}

export default PdfLoader