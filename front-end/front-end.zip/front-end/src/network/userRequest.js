import { request } from '../common/request'

export default {

    login(user) {
        return request({
            url: "/auth/login",
            method: 'post',
            data: user
        })
    },


    register(newUser) {
        return request({
            url: "/auth/register",
            method: 'post',
            data: newUser
        })
    },

    getUserInfoByToken(token) {
        return request({
            url: "/auth/getUserInfoByToken",
            method: 'get',
            params: {
                token
            }
        })
    },


    getAllUsers() {
        return request({
            url: "/user/getAllUsers",
            method: 'get',
        })
    },

    search(username,email) {
        return request({
            url: "/user/search",
            method: 'get',
            params: {
                username,
                email
            }
        })
    },

    createUser(user) {
        return request({
            url: "/user",
            method: 'post',
            data: user
        })
    },


    updateUser(updateUser) {
        return request({
            url: "/user",
            method: 'put',
            data: updateUser
        })
    },


    deleteUser(id) {
        return request({
            url: "/user/" + id,
            method: 'delete',
        })
    },



    getList(dTO) {
        return request({
            url: "events/getList",
            method: 'post',
            data: dTO
        })
    },


    getByTeam(dTO) {
        return request({
            url: "events/team",
            method: 'post',
            data: dTO
        })
    },





    createEvent(event) {
        return request({
            url: "/events",
            method: 'post',
            data: event
        })
    },



    update(event) {
        return request({
            url: "/events",
            method: 'put',
            data: event
        })
    },



    delete(eventId) {
        return request({
            url: "/events",
            method: 'delete',
            data: eventId
        })
    },

    getAllTeams() {
        return request({
            url: "/team/getAllTeams",
            method: 'get',
        })
    },



    getProductList(dto) {
        return request({
            url: "/products/getList",
            method: 'post',
            data: dto
        })
    },

    createProduct(product) {
        return request({
            url: "/products",
            method: 'post',
            data: product
        })
    },

    updateProduct(product) {
        return request({
            url: "/products",
            method: 'put',
            data: product
        })
    },

    deleteProduct(productId) {
        return request({
            url: "/products",
            method: 'delete',
            data: productId
        })
    },


    getOrderList(dto) {
        return request({
            url: "/orders/getList",
            method: 'post',
            data: dto
        })
    },

    createOrder(order) {
        return request({
            url: "/orders",
            method: 'post',
            data: order
        })
    },

    updateOrder(order) {
        return request({
            url: "/orders",
            method: 'put',
            data: order
        })
    },

    deleteOrder(orderId) {
        return request({
            url: "/orders",
            method: 'delete',
            data: orderId
        })
    },


    uploadFile(file) {
        let formData = new FormData();
        formData.append("file",file)
        return request({
            url: "/products/uploadFile",
            method: 'post',
            data: formData
        })
    },


    book(orderDTO) {
        return request({
            url: "/products/book",
            method: 'post',
            data: orderDTO
        })
    },


    updateStatusToTransit(order) {
        return request({
            url: "/orders/transit",
            method: 'put',
            data: order
        })
    },

    updateStatusToArrived(order) {
        return request({
            url: "/orders/arrived",
            method: 'put',
            data: order
        })
    },

    updateStatusToReturned(order) {
        return request({
            url: "/orders/returned",
            method: 'put',
            data: order
        })
    },
}